package com.example.gcmtest

import java.util.UUID

/**
 * Pacotes do protocolo GCM (GameSir) - extraídos por engenharia reversa do app oficial 5.8.29.
 * Formato do mapeamento: 1F <tipo> <idBotão> <scan> <flag> <sum>   (sum = soma dos bytes anteriores & 0xFF)
 */
object Gcm {
    val SERVICE: UUID = UUID.fromString("00008650-0000-1000-8000-00805f9b34fb")
    val WRITE_CHAR: UUID = UUID.fromString("0000865f-0000-1000-8000-00805f9b34fb")
    val NOTIFY_CHAR: UUID = UUID.fromString("00008655-0000-1000-8000-00805f9b34fb")
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    const val ID_L4 = 1
    const val ID_R4 = 2

    const val SCAN_X = 0xB7   // GcmScanCode.X = 183
    const val SCAN_Y = 0xB8   // GcmScanCode.Y = 184

    private fun finish(b: ByteArray): ByteArray {
        var s = 0
        for (i in 0 until b.size - 1) s += b[i].toInt() and 0xFF
        b[b.size - 1] = (s and 0xFF).toByte()
        return b
    }

    /** botão traseiro [id] passa a agir como o botão de gamepad com código [scan] */
    fun mappingSet(id: Int, scan: Int): ByteArray =
        finish(byteArrayOf(0x1F, 0x01, id.toByte(), scan.toByte(), 0x00, 0x00))

    fun mappingQuery(id: Int): ByteArray =
        finish(byteArrayOf(0x1F, 0x00, id.toByte(), 0x00, 0x00, 0x00))

    fun mappingReset(id: Int): ByteArray =
        finish(byteArrayOf(0x1F, 0x02, id.toByte(), 0x00, 0x00, 0x00))

    fun hex(b: ByteArray): String =
        b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    /** Interpretação da resposta de keymapping (r[2]=id, r[3]=scan, r[4]=tipo). */
    fun describe(r: ByteArray): String {
        if (r.size < 5) return ""
        val kind = when (r[4].toInt() and 0xFF) {
            0x00 -> "gamepad"
            0x01 -> "teclado/mouse"
            0xFF -> "macro"
            0xFE -> "bind"
            else -> "?"
        }
        return "  -> id=${r[2].toInt() and 0xFF} scan=0x%02X tipo=$kind".format(r[3].toInt() and 0xFF)
    }
}
