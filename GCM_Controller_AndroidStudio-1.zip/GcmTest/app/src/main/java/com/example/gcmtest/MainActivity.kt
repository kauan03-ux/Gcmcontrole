package com.example.gcmtest

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.ArrayDeque

/**
 * Teste: detecta um controle GameSir (Bluetooth), conecta no GATT 0x8650 e
 * troca L4 -> X e R4 -> Y escrevendo pacotes GCM na characteristic 0x865F.
 */
@Suppress("DEPRECATION")
@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var deviceBox: LinearLayout
    private lateinit var showAll: CheckBox
    private lateinit var btnQuery: Button
    private lateinit var btnApply: Button
    private lateinit var btnReset: Button

    private val adapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }
    private val seen = HashSet<String>()

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var ready = false

    private val queue = ArrayDeque<ByteArray>()
    private var busy = false
    private val busyTimeout = Runnable { busy = false; pump() }

    // ------------------------------------------------------------------ UI
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        status = TextView(this).apply { text = "GCM Controller · Desconectado"; textSize = 18f; setTypeface(null, Typeface.BOLD) }
        root.addView(status)

        val btnScan = Button(this).apply { text = "1 · Buscar controle GameSir" }
        btnScan.setOnClickListener { startSearch() }
        root.addView(btnScan)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnDisconnect = Button(this).apply {
            text = "Desconectar"
            setOnClickListener {
                setReady(false); queue.clear(); busy = false
                gatt?.disconnect(); gatt?.close(); gatt = null; writeChar = null
                setStatus("GCM Controller · Desconectado")
                log("Desconexão solicitada.")
            }
        }
        val btnClear = Button(this).apply {
            text = "Limpar registro"
            setOnClickListener { logView.text = "" }
        }
        actions.addView(btnDisconnect, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(btnClear, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)

        showAll = CheckBox(this).apply { text = "Mostrar todos os dispositivos BLE" }
        root.addView(showAll)

        deviceBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceBox)

        btnQuery = Button(this).apply { text = "2 · Consultar L4 / R4" }
        btnQuery.setOnClickListener {
            enqueue(Gcm.mappingQuery(Gcm.ID_L4))
            enqueue(Gcm.mappingQuery(Gcm.ID_R4))
        }
        btnApply = Button(this).apply { text = "3 · Aplicar: L4 → X  |  R4 → Y" }
        btnApply.setOnClickListener {
            enqueue(Gcm.mappingSet(Gcm.ID_L4, Gcm.SCAN_X))
            enqueue(Gcm.mappingSet(Gcm.ID_R4, Gcm.SCAN_Y))
            enqueue(Gcm.mappingQuery(Gcm.ID_L4))
            enqueue(Gcm.mappingQuery(Gcm.ID_R4))
        }
        btnReset = Button(this).apply { text = "4 · Restaurar L4 / R4" }
        btnReset.setOnClickListener {
            enqueue(Gcm.mappingReset(Gcm.ID_L4))
            enqueue(Gcm.mappingReset(Gcm.ID_R4))
            enqueue(Gcm.mappingQuery(Gcm.ID_L4))
            enqueue(Gcm.mappingQuery(Gcm.ID_R4))
        }
        for (b in listOf(btnQuery, btnApply, btnReset)) { b.isEnabled = false; root.addView(b) }

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
        log("GCM Controller v0.2\nPareie o controle nas configurações do Android. Feche o app GameSir antes de testar.\n\nAviso: protocolo experimental; confirme o resultado lendo as respostas abaixo.")
    }

    private fun log(msg: String) {
        main.post { logView.append(msg + "\n") }
    }

    private fun setStatus(s: String) {
        main.post { status.text = s }
    }

    private fun setReady(r: Boolean) {
        ready = r
        main.post { for (b in listOf(btnQuery, btnApply, btnReset)) b.isEnabled = r }
    }

    // ------------------------------------------------------------------ permissões
    private fun neededPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPerms() = neededPerms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPerms()) startSearch() else log("Permissões negadas.")
    }

    // ------------------------------------------------------------------ busca
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.scanRecord?.deviceName ?: result.device.name
            main.post { addCandidate(result.device, name) }
        }
        override fun onScanFailed(errorCode: Int) { log("Falha na busca BLE: $errorCode") }
    }

    private fun startSearch() {
        val ad = adapter
        if (ad == null || !ad.isEnabled) { log("Ative o Bluetooth."); return }
        if (!hasPerms()) { requestPermissions(neededPerms(), 1); return }
        deviceBox.removeAllViews(); seen.clear()
        ad.bondedDevices.forEach { addCandidate(it, it.name) }
        try {
            ad.bluetoothLeScanner?.startScan(scanCb)
            log("Buscando por 10 s...")
            main.postDelayed({
                try { ad.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
                log("Busca encerrada.")
            }, 10_000)
        } catch (e: Exception) { log("Erro ao buscar: ${e.message}") }
    }

    private fun addCandidate(dev: BluetoothDevice, name: String?) {
        val n = name ?: ""
        val match = Regex("(?i)gamesir|nova").containsMatchIn(n)
        if (!match && !showAll.isChecked) return
        if (!seen.add(dev.address)) return
        val btn = Button(this).apply {
            text = (if (n.isEmpty()) "(sem nome)" else n) + "\n" + dev.address
            setOnClickListener { connect(dev) }
        }
        deviceBox.addView(btn)
    }

    // ------------------------------------------------------------------ GATT
    private fun connect(dev: BluetoothDevice) {
        gatt?.close(); gatt = null; setReady(false)
        queue.clear(); busy = false
        log("Conectando em ${dev.name ?: dev.address} ...")
        setStatus("Conectando...")
        gatt = dev.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                log("GATT conectado, descobrindo serviços...")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                log("Desconectado (status $st)")
                setStatus("Desconectado"); setReady(false)
                g.close()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            val svc = g.getService(Gcm.SERVICE)
            if (svc == null) {
                log("Serviço 0x8650 NÃO encontrado. Serviços do dispositivo:")
                g.services.forEach { log("  ${it.uuid}") }
                setStatus("Serviço GCM ausente"); return
            }
            writeChar = svc.getCharacteristic(Gcm.WRITE_CHAR)
            val nc = svc.getCharacteristic(Gcm.NOTIFY_CHAR)
            if (writeChar == null || nc == null) {
                log("Characteristics 0x865F/0x8655 ausentes. Disponíveis:")
                svc.characteristics.forEach { log("  ${it.uuid} props=${it.properties}") }
                setStatus("Characteristic GCM ausente"); return
            }
            log("Serviço GCM ok. props 865F=${writeChar!!.properties} 8655=${nc.properties}")
            g.setCharacteristicNotification(nc, true)
            val d = nc.getDescriptor(Gcm.CCCD)
            if (d == null) { log("CCCD ausente em 8655"); return }
            val value = if (nc.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0)
                BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, value)
            else { d.value = value; g.writeDescriptor(d) }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) {
            log("Notificações em 8655: status=$st")
            if (st == BluetoothGatt.GATT_SUCCESS) { setStatus("GCM Controller · Conectado e pronto"); setReady(true) }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) log("Erro na escrita: status=$st")
            main.post { main.removeCallbacks(busyTimeout); busy = false; pump() }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            onNotify(value)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            onNotify(c.value ?: ByteArray(0))
        }
    }

    private fun onNotify(v: ByteArray) {
        log("<- " + Gcm.hex(v) + Gcm.describe(v))
    }

    // ------------------------------------------------------------------ fila de escrita
    private fun enqueue(pkt: ByteArray) {
        if (!ready) { log("Não está pronto."); return }
        queue.add(pkt); pump()
    }

    private fun pump() {
        if (busy) return
        val pkt = queue.poll() ?: return
        val g = gatt ?: return
        val c = writeChar ?: return
        val wt = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        log("-> " + Gcm.hex(pkt))
        busy = true
        main.postDelayed(busyTimeout, 2000)
        val ok = if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, pkt, wt) == BluetoothGatt.GATT_SUCCESS
        } else {
            c.writeType = wt
            c.value = pkt
            g.writeCharacteristic(c)
        }
        if (!ok) { log("writeCharacteristic recusou o envio"); main.removeCallbacks(busyTimeout); busy = false }
    }

    override fun onDestroy() {
        super.onDestroy()
        gatt?.close()
    }
}
